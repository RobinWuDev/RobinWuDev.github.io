//
//  main.m
//  DesignDemo
//
//  Created by RobinWu on 12/24/13.
//  Copyright (c) 2013 Suncco. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DDAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DDAppDelegate class]));
    }
}
