//
//  DDCommand.m
//  DesignDemo
//
//  Created by RobinWu on 12/24/13.
//  Copyright (c) 2013 Suncco. All rights reserved.
//

#import "DDCommand.h"

@implementation DDCommand

- (id)copyWithZone:(NSZone *)zone {
    DDCommand *command = [[[self class]allocWithZone:zone]init];
    command.text = _text;
    return command;
}

@end
