//
//  DDViewController.m
//  DesignDemo
//
//  Created by RobinWu on 12/24/13.
//  Copyright (c) 2013 Suncco. All rights reserved.
//

#import "DDViewController.h"
#import "DDCommand.h"

@interface DDViewController ()
@property (weak, nonatomic) IBOutlet UIButton *backButton;
@property (weak, nonatomic) IBOutlet UITextField *inputTextField;
@property (strong, nonatomic) NSMutableArray *backCommands;
- (IBAction)pOkAction:(id)sender;
- (IBAction)pBackAction:(id)sender;

@end

@implementation DDViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.backCommands = [NSMutableArray array];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)pOkAction:(id)sender {
    DDCommand *command = [[DDCommand alloc]init];
    command.text = self.inputTextField.text;
    [self.backCommands addObject:[command copy]];
    [self.backButton setEnabled:YES];
    self.inputTextField.text = @"";
}

- (IBAction)pBackAction:(id)sender {
    if (self.backCommands.count > 0) {
        DDCommand *command = [self.backCommands lastObject];
        [self.backCommands removeObject:command];
        if (self.backCommands.count == 0) {
            [self.backButton setEnabled:NO];
        }
        self.inputTextField.text = command.text;
    }
    
}

@end
