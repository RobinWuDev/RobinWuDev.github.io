//
//  DDCommand.h
//  DesignDemo
//
//  Created by RobinWu on 12/24/13.
//  Copyright (c) 2013 Suncco. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DDCommand : NSObject<NSCopying>

@property (copy, nonatomic) NSString *text;
@end
