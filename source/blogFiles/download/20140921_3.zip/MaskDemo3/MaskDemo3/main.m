//
//  main.m
//  MaskDemo3
//
//  Created by RobinWu on 9/21/14.
//  Copyright (c) 2014 RobinWu. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RBAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([RBAppDelegate class]));
    }
}
