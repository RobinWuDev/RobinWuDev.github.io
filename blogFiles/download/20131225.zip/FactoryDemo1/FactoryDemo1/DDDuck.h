//
//  DDStudent.h
//  FactoryDemo1
//
//  Created by RobinWu on 12/25/13.
//  Copyright (c) 2013 Suncco. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DDAnimal.h"

@interface DDDuck : DDAnimal

@end
