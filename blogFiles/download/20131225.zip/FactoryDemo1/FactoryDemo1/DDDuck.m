//
//  DDStudent.m
//  FactoryDemo1
//
//  Created by RobinWu on 12/25/13.
//  Copyright (c) 2013 Suncco. All rights reserved.
//

#import "DDDuck.h"

@implementation DDDuck

- (void)say {
    NSLog(@"嘎嘎嘎");
}

@end
