//
//  DDViewController.m
//  FactoryDemo1
//
//  Created by RobinWu on 12/25/13.
//  Copyright (c) 2013 Suncco. All rights reserved.
//

#import "DDViewController.h"
#import "DDDogFactory.h"
#import "DDDuckFactory.h"

@interface DDViewController ()

@end

@implementation DDViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    DDDuckFactory *duckFactory = [[DDDuckFactory alloc]init];
    DDDogFactory *dogFactory = [[DDDogFactory alloc]init];
    
    DDAnimal *duck = [duckFactory create];
    DDAnimal *dog = [dogFactory create];
    
    [duck say];
    [dog say];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}

@end
