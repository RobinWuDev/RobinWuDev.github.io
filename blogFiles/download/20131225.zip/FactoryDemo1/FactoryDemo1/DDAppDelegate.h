//
//  DDAppDelegate.h
//  FactoryDemo1
//
//  Created by RobinWu on 12/25/13.
//  Copyright (c) 2013 Suncco. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DDAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
