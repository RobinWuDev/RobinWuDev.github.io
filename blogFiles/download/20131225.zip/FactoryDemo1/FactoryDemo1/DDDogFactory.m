//
//  DDDogFactory.m
//  FactoryDemo1
//
//  Created by RobinWu on 12/25/13.
//  Copyright (c) 2013 Suncco. All rights reserved.
//

#import "DDDogFactory.h"
#import "DDDog.h"

@implementation DDDogFactory

- (DDAnimal *)create{
    DDDog *dog = [[DDDog alloc]init];
    return dog;
}

@end
