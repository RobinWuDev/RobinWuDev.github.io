//
//  UIImage+RBMask.m
//  MaskDemo2
//
//  Created by RobinWu on 9/21/14.
//  Copyright (c) 2014 RobinWu. All rights reserved.
//

#import "UIImage+RBMask.h"

@implementation UIImage (RBMask)

- (CGImageRef)rbCopyImageAndAddAlphaChannel:(CGImageRef)sourceImage {
    CGImageRef retVal = NULL;
    
    size_t width = CGImageGetWidth(sourceImage);
    size_t height = CGImageGetHeight(sourceImage);
    
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    
    CGContextRef offscreenContext = CGBitmapContextCreate(NULL, width, height,
                                                          8, 0, colorSpace, kCGImageAlphaPremultipliedFirst);
    
    if (offscreenContext != NULL)
    {
        CGContextDrawImage(offscreenContext, CGRectMake(0, 0, width, height), sourceImage);
        retVal = CGBitmapContextCreateImage(offscreenContext);
        CGContextRelease(offscreenContext);
    }
    
    CGColorSpaceRelease(colorSpace);
    
    return retVal;
}

- (UIImage*)rbMaskWithImage:(UIImage *)maskImage{
    //创建蒙版图片
    CGImageRef maskRef = maskImage.CGImage;
    CGImageRef mask = CGImageMaskCreate(CGImageGetWidth(maskRef),
                                        CGImageGetHeight(maskRef),
                                        CGImageGetBitsPerComponent(maskRef),
                                        CGImageGetBitsPerPixel(maskRef),
                                        CGImageGetBytesPerRow(maskRef),
                                        CGImageGetDataProvider(maskRef), NULL, false);
    
    
    CGImageRef sourceImage = [self CGImage];
    CGImageRef imageWithAlpha = sourceImage;
    
    //处理原图片，原图片需要有透明通道，如果没有需要处理(例如，gif,jpg等等)
    //这里有一定的性能消耗
    if (CGImageGetAlphaInfo(sourceImage) == kCGImageAlphaNone){
        imageWithAlpha = [self rbCopyImageAndAddAlphaChannel:sourceImage];
    }
    
    //创建蒙版处理后的图片
    CGImageRef masked = CGImageCreateWithMask(imageWithAlpha, mask);
    CGImageRelease(mask);
    
    //release imageWithAlpha if it was created by CopyImageAndAddAlphaChannel
    if (sourceImage != imageWithAlpha)
    {
        CGImageRelease(imageWithAlpha);
    }
    
    UIImage* retImage = [UIImage imageWithCGImage:masked];
    CGImageRelease(masked);
    
    return retImage;
}

@end
