//
//  RBViewController.m
//  MaskDemo2
//
//  Created by RobinWu on 9/21/14.
//  Copyright (c) 2014 RobinWu. All rights reserved.
//

#import "RBViewController.h"

#import "UIImage+RBMask.h"

@interface RBViewController ()

@property (weak, nonatomic) IBOutlet UIImageView *demoImageView;

@end

@implementation RBViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    UIImage *image = [UIImage imageNamed:@"demo"];
    UIImage *maskImage = [UIImage imageNamed:@"mask"];
    UIImage *maskedImage = [image rbMaskWithImage:maskImage];
    self.demoImageView.image = maskedImage;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
