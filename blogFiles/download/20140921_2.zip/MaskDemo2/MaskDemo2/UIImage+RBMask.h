//
//  UIImage+RBMask.h
//  MaskDemo2
//
//  Created by RobinWu on 9/21/14.
//  Copyright (c) 2014 RobinWu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (RBMask)

- (UIImage*)rbMaskWithImage:(UIImage *)maskImage;

@end
